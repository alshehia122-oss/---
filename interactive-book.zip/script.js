/* ===========================================================
   كتاب تفاعلي: مغامرة في رؤوس الجبال
   سراج ومهرة وسر كنوز مسندم
   =========================================================== */

const TITLE = "مغامرة في رؤوس الجبال: سراج ومهرة وسر كنوز مسندم";

// نصوص القصة (صفحة لكل عنصر) — الرسومات في مجلد images/
const STORY = [
  `في قلب مدينة خصب الهادئة، كان سراج وأخته مهرة يقلبان صفحات الموسوعة العمانية في مكتبة جدهما "مازن". وفجأة، سقطت من بين الأوراق خريطة قديمة مرسومة باليد. قال الجد مازن بابتسامة: "يا أبنائي، مسندم هي حارسة مضيق هرمز، وجبالها تخفي أسراراً عمرها ملايين السنين. انطلقا، فالمعرفة هي الكنز الذي لا ينضب."`,
  `استقل الشقيقان قارباً خشبياً تقليدياً (داو) ليبدآ رحلتهما البحرية. كانت المياه زرقاء عميقة، وعند مدخل مضيق هرمز، وقف سراج يراقب السفن الضخمة وهي تعبر الممر العالمي. قال سراج بفخر: "انظري يا مهرة، هنا يلتقي العالم، وهذا المضيق هو شريان الحياة للتجارة العالمية كما قرأنا".`,
  `دخل القارب في "خور شم"، فحبست مهرة أنفاسها من جمال المشهد. كانت الجبال الكلسية الشاهقة تبرز من الماء كأنها قلاع طبيعية تحمي الممر المائي. همست مهرة: "هذه هي فيوردات العرب التي تحدثت عنها الموسوعة، الجبال هنا تعانق البحر في مشهد مهيب".`,
  `فجأة، سمعا صوت وثبٍ في الماء! قفزت دلافين المحيط الهندي الرمادية حول قاربهم، وبدأت في تقديم عرض بهلواني رائع. ضحك سراج ومهرة وهما يراقبان ذكاء هذه الكائنات، وأدركا أن الحياة الفطرية في مسندم هي أحد أهم كنوزها الطبيعية.`,
  `توقف القارب عند "جزيرة التلغراف" الصغيرة. نزل سراج ومهرة لاستكشاف بقايا محطة الاتصالات القديمة التي بنيت في القرن التاسع عشر. شرح سراج لأخته: "هنا كان العالم يتصل ببعضه عبر أسلاك تمر في قاع البحر، كانت هذه الصخرة الصغيرة مركزاً للاتصال بين الشرق والغرب".`,
  `لم تقتصر الرحلة على البحر، بل صعدا بسيارة الدفع الرباعي نحو "جبل حريم"، أعلى قمة في المنطقة. هناك، وجد سراج صخرة مليئة بالنقوش الغريبة، فنادت مهرة بدهشة: "سراج، انظر! إنها أصداف وقواقع بحرية في قمة الجبل!". كان هذا دليلاً حياً على أن هذه القمم كانت يوماً قاعاً للمحيط.`,
  `وصلا إلى قرية "كمزار" الفريدة التي تحيط بها الجبال من كل جانب. هناك، استقبلتهما الطفلة "نورة" ووالدها الصياد "راشد". بدأت مهرة تتحدث مع راشد عن تقاليد القرية، فاكتشفت أنهم يتحدثون لغة "الكمزارية"، وهي لغة خاصة تمزج بين العربية والفارسية والهندية والعديد من اللغات الأخرى.`,
  `بينما كانت مهرة تتعلم بعض الكلمات الكمزارية، كان سراج يساعد الصياد راشد في تجهيز شباك الصيد. أخبره راشد عن أنواع الأسماك النادرة التي تعيش في هذه المياه العميقة وعن مهارة أهل مسندم في ركوب البحر منذ الأزل. شعر سراج برباط قوي يربطه بهذا التاريخ العريق.`,
  `عاد سراج ومهرة إلى خصب مع غروب الشمس، حيث كان الجد مازن ينتظرهما. قال سراج: "يا جدي، لقد وجدنا الكنز! إنه ليس ذهباً، بل هو في قصص الناس، وفي عمق التاريخ، وفي جمال الطبيعة". ابتسم الجد وهو يرى في أعينهما شغف المعرفة الذي سيحملانه للأجيال القادمة.`,
];

const N_TEXT   = STORY.length;      // 9 صفحات نصية
const N_LEAVES = N_TEXT + 1;        // الغلاف + 9 أوراق = 10 ورقات
const LAST_H   = 2 * N_LEAVES - 1;  // آخر حالة (صفحة النهاية) = 19
const FLIP_MS  = 950;

/* ------------------------- بناء الصفحات ------------------------- */
const book = document.getElementById("book");
const leaves = [];

function el(tag, cls, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  return e;
}
function imgFace(cls, src, alt) {
  const f = el("div", "face " + cls);
  const i = new Image();
  i.src = src; i.alt = alt; i.draggable = false;
  f.appendChild(i);
  return f;
}
function textFace(n, text) {
  const f = el("div", "face front text");
  f.appendChild(el("div", "running-head", "فريق سراج"));
  const body = el("div", "body");
  const p = document.createElement("p");
  // لف كل كلمة بوسم لتمييزها أثناء القراءة الصوتية
  p.innerHTML = text.split(" ").map(w => `<span class="word">${w}</span>`).join(" ");
  body.appendChild(p);
  f.appendChild(body);
  f.appendChild(el("div", "num", String(n)));
  return f;
}
function endFace() {
  const f = el("div", "face back end");
  f.innerHTML = `
    <div class="ornament">⛰️ ⛵ 🐬</div>
    <h2>النهاية</h2>
    <p>المعرفة هي الكنز الذي لا ينضب.</p>
    <button id="btnRestart">اقرأ القصة من جديد</button>`;
  return f;
}

for (let i = 0; i < N_LEAVES; i++) {
  const leaf = el("div", "leaf");
  leaf.dataset.i = i;

  // الوجه الأمامي (الصفحة اليمنى)
  const front = i === 0
    ? imgFace("front", "images/cover.jpg", "غلاف كتاب مغامرة في رؤوس الجبال")
    : textFace(i, STORY[i - 1]);

  // الوجه الخلفي (الصفحة اليسرى بعد القلب)
  const back = i < N_TEXT
    ? imgFace("back", `images/illus-${i + 1}.jpg`, `رسمة الصفحة ${i + 1}`)
    : endFace();

  leaf.append(front, back);
  book.appendChild(leaf);
  leaves.push(leaf);
}

/* ------------------------- الحالة ------------------------- */
// h: موضع القراءة 0..19
//   الوضع المزدوج: يُستخدم f = ceil(h/2) فقط (عدد الأوراق المقلوبة)
//   الوضع المفرد (الهاتف): صفحة واحدة في كل مرة، رسمة ثم نص
let h = 0;
let single = false;
let scale = 1;
let locked = false;

const f = () => Math.ceil(h / 2);
const $ = id => document.getElementById(id);
const btnPrev = $("btnPrev"), btnNext = $("btnNext");

function computeMode() {
  return window.innerWidth < 900 && window.innerWidth / window.innerHeight < 1.1;
}

function fit() {
  const stage = $("stage");
  const W = 500, H = 778;
  const availW = stage.clientWidth - 16;
  const availH = stage.clientHeight - 16;
  const needW = single ? W : 2 * W;
  scale = Math.min(availW / needW, availH / H, 1.5);
  render(false);
}

function shiftPx() {
  const W = 500;
  if (single) return (h % 2 === 1) ? W / 2 : -W / 2;      // يسار = رسمة، يمين = نص
  if (f() === 0) return -W / 2;                           // الغلاف وحده
  if (f() === N_LEAVES) return W / 2;                     // صفحة النهاية وحدها
  return 0;
}

function setLeaf(i, flipped, animate) {
  const leaf = leaves[i];
  const was = leaf.classList.contains("flipped");
  if (was === flipped) { leaf.style.zIndex = flipped ? i : N_LEAVES - i; return; }
  if (animate) {
    leaf.classList.add("turning");
    leaf.style.zIndex = 100;
    setTimeout(() => {
      leaf.classList.remove("turning");
      leaf.style.zIndex = flipped ? i : N_LEAVES - i;
    }, FLIP_MS);
  } else {
    leaf.style.zIndex = flipped ? i : N_LEAVES - i;
  }
  leaf.classList.toggle("flipped", flipped);
}

function label() {
  const k = f();
  if (k === 0) return "الغلاف";
  if (k === N_LEAVES) return "النهاية";
  return `الصفحة ${k} من ${N_TEXT}`;
}

function render(animate = true) {
  const k = f();
  leaves.forEach((_, i) => setLeaf(i, i < k, animate));
  book.style.transform = `translateX(${shiftPx() * scale}px) scale(${scale})`;
  $("pageLabel").textContent = label();
  $("barFill").style.width = (h / LAST_H * 100) + "%";
  btnPrev.disabled = h === 0;
  btnNext.disabled = h === LAST_H;
}

/* ------------------------- التنقل ------------------------- */
function go(dir) {
  if (locked) return;
  const old = h;
  if (single) {
    h = Math.min(LAST_H, Math.max(0, h + dir));
  } else {
    const nf = Math.min(N_LEAVES, Math.max(0, f() + dir));
    h = nf === 0 ? 0 : (nf === N_LEAVES ? LAST_H : 2 * nf);
  }
  if (h === old) return;

  stopSpeaking();
  hideHint();
  const flips = Math.ceil(h / 2) !== Math.ceil(old / 2);
  if (flips) playFlip();
  render(true);

  locked = true;
  setTimeout(() => (locked = false), flips ? 520 : 350);
}
const next = () => go(+1);
const prev = () => go(-1);

btnNext.addEventListener("click", next);
btnPrev.addEventListener("click", prev);

// النقر على الصفحة نفسها
book.addEventListener("click", e => {
  if (suppressClick) return;
  if (e.target.closest("button")) return;
  const leaf = e.target.closest(".leaf");
  if (!leaf) return;
  if (single) return next();
  leaf.classList.contains("flipped") ? prev() : next();
});

// إعادة القراءة من البداية
document.addEventListener("click", e => {
  if (e.target.id === "btnRestart") {
    stopSpeaking();
    h = 0; playFlip(); render(true);
  }
});

// لوحة المفاتيح: السهم الأيسر = التالي (الصفحة تنتقل نحو اليسار)
document.addEventListener("keydown", e => {
  switch (e.key) {
    case "ArrowLeft": case "PageDown": case " ": e.preventDefault(); next(); break;
    case "ArrowRight": case "PageUp": e.preventDefault(); prev(); break;
    case "Home": h = 0; render(true); break;
    case "End": h = LAST_H; render(true); break;
  }
});

// السحب باللمس أو الفأرة
let sx = null, suppressClick = false;
const stage = $("stage");
stage.addEventListener("pointerdown", e => { sx = e.clientX; });
stage.addEventListener("pointerup", e => {
  if (sx === null) return;
  const dx = e.clientX - sx; sx = null;
  if (Math.abs(dx) > 55) {
    suppressClick = true; setTimeout(() => (suppressClick = false), 60);
    dx < 0 ? next() : prev();
  }
});
stage.addEventListener("pointercancel", () => (sx = null));

/* ------------------------- التلميح ------------------------- */
function hideHint() { $("hint").classList.add("gone"); }
setTimeout(hideHint, 9000);

/* ------------------------- صوت تقليب الصفحة ------------------------- */
let soundOn = true, actx = null;
$("btnSound").addEventListener("click", () => {
  soundOn = !soundOn;
  $("btnSound").classList.toggle("off", !soundOn);
  $("btnSound").textContent = soundOn ? "🔔" : "🔕";
});
function playFlip() {
  if (!soundOn) return;
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const dur = 0.45, rate = actx.sampleRate;
    const buf = actx.createBuffer(1, rate * dur, rate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < d.length; i++) {
      const t = i / d.length;
      d[i] = (Math.random() * 2 - 1) * Math.sin(Math.PI * t) * (1 - t * 0.6);
    }
    const src = actx.createBufferSource(); src.buffer = buf;
    const bp = actx.createBiquadFilter(); bp.type = "bandpass"; bp.Q.value = 0.8;
    bp.frequency.setValueAtTime(1200, actx.currentTime);
    bp.frequency.exponentialRampToValueAtTime(4200, actx.currentTime + dur);
    const g = actx.createGain(); g.gain.value = 0.18;
    src.connect(bp).connect(g).connect(actx.destination);
    src.start();
  } catch (_) { /* تجاهل */ }
}

/* ------------------------- القراءة الصوتية ------------------------- */
const btnRead = $("btnRead");
let speaking = false;

function currentText() {
  const k = f();
  if (k === 0) return { text: TITLE, words: null };
  if (k === N_LEAVES) return { text: "النهاية. المعرفة هي الكنز الذي لا ينضب.", words: null };
  const words = leaves[k].querySelectorAll(".face.front .word");
  return { text: STORY[k - 1], words };
}

function stopSpeaking() {
  if ("speechSynthesis" in window) speechSynthesis.cancel();
  document.querySelectorAll(".word.hl").forEach(w => w.classList.remove("hl"));
  speaking = false;
  btnRead.classList.remove("speaking");
  btnRead.textContent = "🔊 استمع";
}

function toast(msg) {
  const t = el("div", "toast", msg);
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}

btnRead.addEventListener("click", () => {
  if (!("speechSynthesis" in window)) return toast("المتصفح لا يدعم القراءة الصوتية");
  if (speaking) return stopSpeaking();

  const voices = speechSynthesis.getVoices();
  const ar = voices.find(v => v.lang && v.lang.toLowerCase().startsWith("ar"));
  if (voices.length && !ar) return toast("لا يتوفر صوت عربي على جهازك حالياً");

  const { text, words } = currentText();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = ar ? ar.lang : "ar-SA";
  if (ar) u.voice = ar;
  u.rate = 0.85;

  // مواضع بداية كل كلمة لتمييزها أثناء النطق
  let starts = [];
  if (words) {
    let pos = 0;
    text.split(" ").forEach(w => { starts.push(pos); pos += w.length + 1; });
  }
  u.onboundary = e => {
    if (!words || e.charIndex === undefined) return;
    let idx = starts.findIndex((s, i) => e.charIndex >= s && (i === starts.length - 1 || e.charIndex < starts[i + 1]));
    words.forEach((w, i) => w.classList.toggle("hl", i === idx));
  };
  u.onend = u.onerror = stopSpeaking;

  speaking = true;
  btnRead.classList.add("speaking");
  btnRead.textContent = "⏹ إيقاف";
  speechSynthesis.speak(u);
});
if ("speechSynthesis" in window) speechSynthesis.getVoices();

/* ------------------------- ملء الشاشة ------------------------- */
$("btnFull").addEventListener("click", () => {
  if (!document.fullscreenElement) document.documentElement.requestFullscreen?.();
  else document.exitFullscreen?.();
});

/* ------------------------- تحديد الوضع وتغيير الحجم ------------------------- */
function onResize() {
  const s = computeMode();
  if (s !== single) {
    single = s;
    if (!single && h % 2 === 1 && h !== LAST_H) h += 1;   // الانتقال إلى العرض المزدوج
  }
  fit();
}
window.addEventListener("resize", onResize);
single = computeMode();
// ضبط أولي بدون حركة
document.querySelectorAll(".leaf").forEach(l => (l.style.transition = "none"));
book.style.transition = "none";
fit();
requestAnimationFrame(() => requestAnimationFrame(() => {
  document.querySelectorAll(".leaf").forEach(l => (l.style.transition = ""));
  book.style.transition = "";
}));
